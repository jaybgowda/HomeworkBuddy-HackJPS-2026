import { formatDateKey } from './helpers.js';

export const selectedDates = new Set();
export let activeYear = 0;
export let activeMonth = 0;

let calendarBody;
let taskPanel;
let selectedDateLabel;
let taskInput;
let monthLabel;
let onSelectionChanged = () => {};

export function initCalendar({
  initialDate,
  calendarBody: body,
  taskPanel: panel,
  selectedDateLabel: label,
  taskInput: input,
  monthLabel: labelEl,
  prevMonthButton,
  nextMonthButton,
  prevYearButton,
  nextYearButton,
  onSelectionChanged: selectionCallback,
}) {
  activeYear = initialDate.getFullYear();
  activeMonth = initialDate.getMonth();
  calendarBody = body;
  taskPanel = panel;
  selectedDateLabel = label;
  taskInput = input;
  monthLabel = labelEl;
  onSelectionChanged = selectionCallback || (() => {});

  prevMonthButton.addEventListener('click', () => changeMonth(-1));
  nextMonthButton.addEventListener('click', () => changeMonth(1));
  prevYearButton.addEventListener('click', () => changeYear(-1));
  nextYearButton.addEventListener('click', () => changeYear(1));

  updateMonthLabel();
  renderCalendar();
}

export function getActiveDateKey(day) {
  return formatDateKey(activeYear, activeMonth, day);
}

function updateMonthLabel() {
  if (!monthLabel) return;
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  monthLabel.textContent = `${monthNames[activeMonth]} ${activeYear}`;
}

export function renderCalendar() {
  calendarBody.innerHTML = '';
  const daysInMonth = new Date(activeYear, activeMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(activeYear, activeMonth, 1).getDay();
  let date = 1;

  for (let row = 0; row < 6; row += 1) {
    const tr = document.createElement('tr');

    for (let col = 0; col < 7; col += 1) {
      const td = document.createElement('td');

      if (row === 0 && col < firstDayOfMonth) {
        td.textContent = '';
        td.style.background = '#fafafa';
        td.style.cursor = 'default';
      } else if (date <= daysInMonth) {
        const currentDate = date;
        td.textContent = currentDate;
        td.dataset.date = currentDate;
        td.addEventListener('click', () => toggleDateSelection(currentDate));
        date += 1;
      } else {
        td.textContent = '';
        td.style.background = '#fafafa';
        td.style.cursor = 'default';
      }

      tr.appendChild(td);
    }

    calendarBody.appendChild(tr);
  }
}

export function changeMonth(delta) {
  activeMonth += delta;

  if (activeMonth < 0) {
    activeMonth = 11;
    activeYear -= 1;
  } else if (activeMonth > 11) {
    activeMonth = 0;
    activeYear += 1;
  }

  clearSelection();
  renderCalendar();
  updateMonthLabel();
  onSelectionChanged();
}

export function changeYear(delta) {
  activeYear += delta;
  clearSelection();
  renderCalendar();
  updateMonthLabel();
  onSelectionChanged();
}

function toggleDateSelection(date) {
  if (selectedDates.has(date)) {
    selectedDates.delete(date);
  } else {
    selectedDates.add(date);
  }

  updateSelectedCells();

  if (selectedDates.size === 0) {
    taskPanel.classList.add('hidden');
  } else {
    taskPanel.classList.remove('hidden');
  }

  selectedDateLabel.textContent = getSelectedDatesLabel();
  taskInput.value = '';
  onSelectionChanged();
}

function clearSelection() {
  selectedDates.clear();
  updateSelectedCells();
  taskPanel.classList.add('hidden');
  selectedDateLabel.textContent = 'Selected date:';
  taskInput.value = '';
}

function updateSelectedCells() {
  document.querySelectorAll('.calendar td').forEach(td => {
    const date = Number(td.dataset.date);
    td.classList.toggle('selected', selectedDates.has(date));
  });
}

function getSelectedDatesLabel() {
  if (selectedDates.size === 0) return 'Selected date:';
  const sortedDates = [...selectedDates].sort((a, b) => a - b);
  return selectedDates.size === 1
    ? `Selected date: ${sortedDates[0]}`
    : `Selected dates: ${sortedDates.join(', ')}`;
}
