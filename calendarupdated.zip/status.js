import { getTodayKey, getTodayDate, getYesterdayKey } from './helpers.js';

const LEVEL_STORAGE_KEY = 'homeworkBuddyLevel';
const LAST_COMPLETION_KEY = 'homeworkBuddyLastCompletion';
const LAST_MISSED_CHECK_KEY = 'homeworkBuddyLastMissedCheck';

let level = loadLevel();
let lastCompletionDate = localStorage.getItem(LAST_COMPLETION_KEY);
let lastMissedCheck = localStorage.getItem(LAST_MISSED_CHECK_KEY);

let progressFillElement;
let progressTextElement;
let levelLabelElement;

export function initStatus({ progressFill, progressText, levelLabel }) {
  progressFillElement = progressFill;
  progressTextElement = progressText;
  levelLabelElement = levelLabel;
  updateLevelLabel();
}

function loadLevel() {
  const stored = Number(localStorage.getItem(LEVEL_STORAGE_KEY));
  return Number.isInteger(stored) && stored >= 0 ? stored : 0;
}

function saveLevel() {
  localStorage.setItem(LEVEL_STORAGE_KEY, String(level));
  updateLevelLabel();
}

function updateLevelLabel() {
  if (levelLabelElement) {
    levelLabelElement.textContent = String(level);
  }
}

function markTodayComplete() {
  const todayKey = getTodayKey();

  if (!lastCompletionDate || lastCompletionDate !== todayKey) {
    lastCompletionDate = todayKey;
    localStorage.setItem(LAST_COMPLETION_KEY, todayKey);
    level += 1;
    saveLevel();
  }
}

export function renderTodayProgress(tasksByDate) {
  const todayKey = getTodayKey();
  const todayTasks = tasksByDate[todayKey] || [];
  const totalToday = todayTasks.length;
  const completedToday = todayTasks.filter(task => task.completed).length;
  const fillPercent = totalToday === 0 ? 0 : Math.round((completedToday / totalToday) * 100);

  if (progressFillElement) {
    progressFillElement.style.width = `${fillPercent}%`;
  }

  if (progressTextElement) {
    progressTextElement.textContent = totalToday === 0
      ? 'No tasks for today'
      : `${fillPercent}% complete (${completedToday}/${totalToday})`;
  }

  if (totalToday > 0 && completedToday === totalToday) {
    markTodayComplete();
  }
}

export function checkMissedPreviousDay(tasksByDate) {
  const yesterdayKey = getYesterdayKey();
  if (lastMissedCheck === yesterdayKey) {
    return;
  }

  const tasks = tasksByDate[yesterdayKey] || [];
  const missed = tasks.some(task => !task.completed);

  if (missed) {
    level = Math.max(0, level - 1);
    saveLevel();
  }

  localStorage.setItem(LAST_MISSED_CHECK_KEY, yesterdayKey);
  lastMissedCheck = yesterdayKey;
}
