import { selectedDates, getActiveDateKey } from './calendar.js';
import { formatLabelFromKey, parseDateKey, getTodayDate, getTodayKey } from './helpers.js';

export const tasksByDate = {};

let dateTaskList;
let pendingTasks;
let completedTasks;
let taskChangedCallback = () => {};

export function initTasks({ dateTaskList: list, pendingTasks: pending, completedTasks: completed, onTaskChanged }) {
  dateTaskList = list;
  pendingTasks = pending;
  completedTasks = completed;
  taskChangedCallback = onTaskChanged || (() => {});
}

export function addTaskForSelectedDates(text) {
  selectedDates.forEach(date => {
    const dateKey = getActiveDateKey(date);
    if (!tasksByDate[dateKey]) {
      tasksByDate[dateKey] = [];
    }
    tasksByDate[dateKey].push({ text, completed: false });
  });
  taskChangedCallback();
}

export function completeTask(taskInfo) {
  const dateTasks = tasksByDate[taskInfo.key];
  if (!dateTasks) return false;

  const index = dateTasks.findIndex(task => task.text === taskInfo.text && !task.completed);
  if (index >= 0) {
    dateTasks[index].completed = true;
    taskChangedCallback();
    return taskInfo.key === getTodayKey();
  }

  return false;
}

export function renderDateTasks() {
  dateTaskList.innerHTML = '';

  if (selectedDates.size === 0) {
    return;
  }

  const sortedDates = [...selectedDates].sort((a, b) => a - b);

  sortedDates.forEach(date => {
    const dateKey = getActiveDateKey(date);
    const tasks = (tasksByDate[dateKey] || []).filter(task => !task.completed);

    if (tasks.length === 0) {
      const emptyItem = document.createElement('li');
      emptyItem.textContent = `${date}: No tasks yet for this date.`;
      dateTaskList.appendChild(emptyItem);
    } else {
      tasks.forEach(task => {
        const li = document.createElement('li');
        li.textContent = `${task.text}`;
        dateTaskList.appendChild(li);
      });
    }
  });
}

export function renderPendingTasks() {
  pendingTasks.innerHTML = '';
  const allTasks = [];

  Object.keys(tasksByDate).sort().forEach(dateKey => {
    tasksByDate[dateKey].forEach(task => {
      if (!task.completed) {
        allTasks.push({ date: dateKey, text: task.text, key: dateKey });
      }
    });
  });

  if (allTasks.length === 0) {
    const noTasks = document.createElement('div');
    noTasks.textContent = 'No pending tasks.';
    pendingTasks.appendChild(noTasks);
    return;
  }

  const todayDate = getTodayDate();

  allTasks.forEach(task => {
    const taskRow = document.createElement('div');
    const taskDate = parseDateKey(task.date);
    const overdue = taskDate < todayDate;

    taskRow.className = `pending-task ${overdue ? 'overdue' : 'normal'}`;

    const label = document.createElement('span');
    label.textContent = `${formatLabelFromKey(task.date)}: ${task.text}`;
    const completeButton = document.createElement('button');
    completeButton.textContent = 'Complete';
    completeButton.addEventListener('click', () => completeTask(task));

    taskRow.appendChild(label);
    taskRow.appendChild(completeButton);
    pendingTasks.appendChild(taskRow);
  });
}

export function renderCompletedTasks() {
  completedTasks.innerHTML = '';
  const allCompleted = [];

  Object.keys(tasksByDate).forEach(dateKey => {
    tasksByDate[dateKey].forEach(task => {
      if (task.completed) {
        allCompleted.push({ date: dateKey, text: task.text });
      }
    });
  });

  if (allCompleted.length === 0) {
    const noTasks = document.createElement('div');
    noTasks.textContent = 'No completed tasks yet.';
    completedTasks.appendChild(noTasks);
    return;
  }

  allCompleted.forEach(task => {
    const taskRow = document.createElement('div');
    taskRow.className = 'pending-task';
    taskRow.textContent = `${formatLabelFromKey(task.date)}: ${task.text}`;
    completedTasks.appendChild(taskRow);
  });
}
