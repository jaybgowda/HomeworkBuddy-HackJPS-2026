import { initCalendar } from './calendar.js';
import { initTasks, addTaskForSelectedDates, renderDateTasks, renderPendingTasks, renderCompletedTasks, tasksByDate } from './tasks.js';
import { initStatus, renderTodayProgress, checkMissedPreviousDay } from './status.js';

function updateAllViews() {
  renderDateTasks();
  renderPendingTasks();
  renderCompletedTasks();
  renderTodayProgress(tasksByDate);
}

document.addEventListener('DOMContentLoaded', () => {
  const calendarBody = document.getElementById('calendarBody');
  const taskPanel = document.getElementById('taskPanel');
  const selectedDateLabel = document.getElementById('selectedDateLabel');
  const taskInput = document.getElementById('taskInput');
  const saveTaskButton = document.getElementById('saveTaskButton');
  const dateTaskList = document.getElementById('dateTaskList');
  const pendingTasks = document.getElementById('pendingTasks');
  const completedTasks = document.getElementById('completedTasks');
  const prevMonthButton = document.getElementById('prevMonthButton');
  const nextMonthButton = document.getElementById('nextMonthButton');
  const prevYearButton = document.getElementById('prevYearButton');
  const nextYearButton = document.getElementById('nextYearButton');
  const monthLabel = document.getElementById('monthLabel');
  const progressFill = document.getElementById('progressFill');
  const progressText = document.getElementById('progressText');
  const levelLabel = document.getElementById('levelLabel');

  initCalendar({
    initialDate: new Date(),
    calendarBody,
    taskPanel,
    selectedDateLabel,
    taskInput,
    monthLabel,
    prevMonthButton,
    nextMonthButton,
    prevYearButton,
    nextYearButton,
    onSelectionChanged: updateAllViews,
  });

  initTasks({
    dateTaskList,
    pendingTasks,
    completedTasks,
    onTaskChanged: updateAllViews,
  });

  initStatus({
    progressFill,
    progressText,
    levelLabel,
  });

  saveTaskButton.addEventListener('click', () => {
    const text = taskInput.value.trim();
    if (!text) return;
    addTaskForSelectedDates(text);
    taskInput.value = '';
    updateAllViews();
  });

  updateAllViews();
  checkMissedPreviousDay(tasksByDate);
});
